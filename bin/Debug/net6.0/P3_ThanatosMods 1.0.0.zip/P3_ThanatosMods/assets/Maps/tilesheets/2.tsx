<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="2" tilewidth="16" tileheight="16" tilecount="1312" columns="32">
 <image source="../Content (unpacked)/Maps/townInterior_2" width="512" height="656"/>
</tileset>
