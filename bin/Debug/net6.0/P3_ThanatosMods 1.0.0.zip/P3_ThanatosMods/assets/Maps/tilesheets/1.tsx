<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="1" tilewidth="16" tileheight="16" tilecount="2176" columns="32">
 <image source="../Content (unpacked)/Maps/townInterior" width="512" height="1088"/>
</tileset>
